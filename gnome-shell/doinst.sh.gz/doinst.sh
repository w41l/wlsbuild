if [ -x usr/bin/update-desktop-database ]; then
  usr/bin/update-desktop-database 1> /dev/null 2> /dev/null
fi

# glib2 compile schemas
if [ -x usr/bin/glib-compile-schemas ]; then
  usr/bin/glib-compile-schemas usr/share/glib-2.0/schemas
fi

# Add removed close button for windows
if [ -x usr/bin/gconftool-2 ]; then
  # Add removed close button for windows
  #usr/bin/gconftool-2 -s -t string /desktop/gnome/shell/windows/button_layout ":close"
  usr/bin/gconftool-2 -s -t int /desktop/gnome/peripherals/mouse/cursor_size "32"
  # Add removed close, minimise and maximise button for windows
  usr/bin/gconftool-2 -s -t string /desktop/gnome/shell/windows/button_layout ":minimize,maximize,close"
fi;
